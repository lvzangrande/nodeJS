const diagnostico = {
  node: process.version,
  // TODO: acrescente plataforma e diretorioAtual usando o objeto process.
};

if (!diagnostico.plataforma || !diagnostico.diretorioAtual) {
  console.error('PENDENTE: complete o diagnóstico do ambiente.');
  process.exitCode = 1;
} else {
  console.table(diagnostico);
}
